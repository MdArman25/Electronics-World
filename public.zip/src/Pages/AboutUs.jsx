import Client from "../Components/Client";
import OurTeam from "../Components/OurTeam";

const AboutUs = () => {
    return (
        <div>
        
        <OurTeam></OurTeam>
            <Client></Client>
        </div>
    );
};
export default AboutUs;
