import ContactFrom from "../Components/ContactFrom";
import MapGoogle from "../Components/GoogleMap";

const Contact = () => {
  return (
    <div className="mt-20">
      <div className="w-full ">
        <MapGoogle></MapGoogle>
      </div>
      <ContactFrom></ContactFrom>
    </div>
  );
};

export default Contact;
